from setuptools import setup

setup(
    name="paquetecalculos",
    version="1.0",
    description="Paquete de redondeo y potencia",
    author="54DK1",
    author_email="71perrodro01@gmail.com",
    url="N/A",
    packages=["calculos", "calculos.redondeo_potencia"]
)